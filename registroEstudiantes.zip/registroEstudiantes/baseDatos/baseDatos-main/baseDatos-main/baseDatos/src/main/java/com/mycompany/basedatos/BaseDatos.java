/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.basedatos;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

import java.util.Scanner;
import mundo.Alumno;

/**
 *
 * @author Leidy Cuasquer 
 */
public class BaseDatos {

    public static void main(String[] args) throws FileNotFoundException {
        //Definiendo variables lector y activo
        Scanner lector = new Scanner(System.in);
        boolean activo = true;
        
        //creando el array en el que se va a guardar cada cosa
        ArrayList<Alumno> listadoAlumnos = new ArrayList<Alumno>();
        
        //Se abre un do-while para que el menu se repita hasta que la bandera sea 5
        do {
            System.out.println("1. Insertar Alumno");
            System.out.println("2. Eliminar Alumno");
            System.out.println("3. Modificar Alumno");
            System.out.println("4. Consultar Alumno");
            System.out.println("5. Terminar Programa:");
            System.out.print("Seleccione una opción: ");
            
            int opcion = lector.nextInt();
           
           
            switch (opcion) {
                case 1:
                 //Se hacen los llamados de cada case, insertar alumno, eliminar, modificar y consultar Alumno.  
                    System.out.println("OPCION 1: INSERTAR ALUMNO");
                    insertarAlumno(listadoAlumnos, lector);
                    break;
                case 2:
                
                    System.out.println("OPCION 2: ELIMINAR ALUMNO");
                    eliminarAlumno(listadoAlumnos, lector);
                    break;
                case 3:
                    System.out.println("OPCION mno3: modificar un alumno");
                    modificarAlumno(listadoAlumnos,lector);
                    break;
                case 4:
                    System.out.println("OPCION 4: consultar un alumno");
                    mostrarAlumnos(listadoAlumnos);
                    break;
                 
                case 5:
                    // se cierra el programa                
                    System.out.println("SALIR DEL PROGRAMA");
                    activo = false;
                    break;
                default:
                    System.out.println("ups!! no has seleccionado ninguna opcion, intenta de nuevo");
                    break;
            }
            //Cerramos el while
        } while (activo);
         //cerramos el lector
        lector.close();
    }
    
    //Funcion para insertar un nuevo alumno

    public static Alumno insertarAlumno(ArrayList<Alumno> listadoAlumnos, Scanner lector) {
    Alumno nAlumno = new Alumno();
    //Listado de alumnos
    
    System.out.print("Ingrese un nombre: ");
    String nombre = lector.next();
    while (nombre.isEmpty()) {
        System.out.println("El nombre no puede estar en blanco. Por favor, ingrese un nombre.");
        nombre = lector.next();
    }
    nAlumno.setNombre(nombre);
        

    System.out.print("Ingrese un apellido: ");
    String apellido = lector.next();
    while (apellido.isEmpty()) {
        System.out.println("El apellido no puede estar en blanco. Por favor, ingrese un apellido.");
        apellido = lector.next();
    }
    nAlumno.setApellido(apellido);


    System.out.print("Ingrese una cédula: ");
    String cedula = lector.next();
    while (cedula.isEmpty()) {
        System.out.println("La cédula no puede estar en blanco. Por favor, ingrese una cédula.");
        cedula = lector.next();
    }
    nAlumno.setCedula(cedula);

    System.out.print("Ingrese un semestre: ");
    String semestre = lector.next();
    while (semestre.isEmpty()) {
        System.out.println("El semestre no puede estar en blanco. Por favor, ingrese un semestre.");
        semestre = lector.next();
    }
    nAlumno.setSemestre(semestre);

    System.out.print("Ingrese un correo: ");
    String correo = lector.next();
    while (correo.isEmpty()) {
        System.out.println("El correo no puede estar en blanco. Por favor, ingrese un correo.");
        correo = lector.next();
    }
    nAlumno.setCorreo(correo);

    System.out.print("Ingrese un celular: ");
    String celular = lector.next();
    while (celular.isEmpty()) {
        System.out.println("El celular no puede estar en blanco. Por favor, ingrese un celular.");
        celular = lector.next();
    }
    nAlumno.setCelular(celular);
 
    
    
    listadoAlumnos.add(new Alumno(nombre, apellido, cedula,semestre,celular,correo));
    System.out.println("Te has registrado correctamente.");

    return nAlumno;
}

   
    
    public static void eliminarAlumno(ArrayList<Alumno> listadoAlumnos, Scanner lector) {
           System.out.println("ingrese la cedula");
           String cEliminar=lector.next();
           lector.nextInt();
           for(Alumno nAlum: listadoAlumnos){
               if(cEliminar.equals(nAlum.getCedula())){
                   listadoAlumnos.remove(nAlum);
                   System.out.println("se ha eliminado");
                   break;
               }else{
                   System.out.println("no se encontro");
               }
           }
           

}
    
    public static void modificarAlumno(ArrayList<Alumno> listadoAlumnos, Scanner lector) {
    System.out.print("Ingrese la cédula del alumno a modificar: ");
    String cedulaModificar = lector.next();

    boolean encontrado = false;
    for (Alumno alumno : listadoAlumnos) {
        if (alumno.getCedula().equals(cedulaModificar)) {
            System.out.println("modificar datos: " + alumno.getNombre() + " " + alumno.getApellido());

            System.out.print("ingrese un nuevo nombre ");
            String nNombre = lector.next();
            if (!nNombre.isEmpty()) {
                alumno.setNombre(nNombre);
            }

            System.out.print("ingrese un nuevo apellido: ");
            String nApellido = lector.next();
            if (!nApellido.isEmpty()) {
                alumno.setApellido(nApellido);
            }

            System.out.print("Ingrese un nuevo semestre): ");
            String nSemestre = lector.next();
            if (!nSemestre.isEmpty()) {
                alumno.setSemestre(nSemestre);
            }

            System.out.print("Ingrese un nuevo correo: ");
            String nCorreo = lector.next();
            if (!nCorreo.isEmpty()) {
                alumno.setCorreo(nCorreo);
            }

            System.out.print("Ingrese un nuevo celular: ");
            String nCelular = lector.next();
            if (!nCelular.isEmpty()) {
                alumno.setCelular(nCelular);
            }

            System.out.println("Se modificaron los datos correctamente.");
            encontrado = true;
            break;
        }
    }

    if (!encontrado) {
        System.out.println("Hubo un error al buscar este alumno, ingrese la cedula nuevamente.");
    }
}
    
    public static void mostrarAlumnos(ArrayList<Alumno> listadoAlumnos) {
    if (listadoAlumnos.isEmpty()) {
        System.out.println("No se ha encontrado ninguna lista.");
    } else {
        System.out.println("Listado de Alumnos:");
        for (Alumno alumno : listadoAlumnos) {
            System.out.println("Nombre: " + alumno.getNombre());
            System.out.println("Apellido: " + alumno.getApellido());
            System.out.println("Cédula: " + alumno.getCedula());
            System.out.println("Semestre: " + alumno.getSemestre());
            System.out.println("Correo: " + alumno.getCorreo());
            System.out.println("Celular: " + alumno.getCelular());
            System.out.println("===================================");
        }
    }
}
    }
